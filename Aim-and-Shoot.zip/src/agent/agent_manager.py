from .ans_agent import AnSEnvDefault, AnSBayesianUpdateVersion, AnST1AVersion1

ANS_ENV = dict(
    default = AnSEnvDefault,
    AnSBayesianUpdateVersion = AnSBayesianUpdateVersion,
    AnST1AVersion1 = AnST1AVersion1
)